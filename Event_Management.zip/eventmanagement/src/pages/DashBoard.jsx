import React, { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import { getEvents, saveEvents } from "../utils/storage";
function DashBoard() {
  const [events, setEvents] = useState([]);
  const [search, setSearch] = useState("");
  const [eventtype, setEventtype] = useState("");
  useEffect(() => {
    setEvents(getEvents());
  }, []);
  const deleteEvent = (id) => {
    const updated = events.filter((e) => e.id !== id);
    saveEvents(updated);
    setEvents(updated);
  };
  const SearchEvents = events.filter((e) => {
    const eventSearch =
      e.name.toLowerCase().includes(search.toLowerCase()) ||
      e.location.toLowerCase().includes(search.toLowerCase());
    const eventTypes = eventtype === "" || e.type === eventtype;

    return eventSearch && eventTypes;
  });
  return (
    <div className="dashboard">
      <div className="container mt-4">
        <h1>Event Management Dashboard</h1>
        <div className="nav">
          <div className="addbtn">
            <Link
              to="/add"
              className="btn-light ps-3 pe-3 pt-2 pb-2"
              style={{ textDecoration: "none" }}
            >
              Add Event
            </Link>
          </div>
          <div className="findEvents">
            <input
              type="text"
              placeholder="Search by name or location"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="search"
            />
            <div>
              <select
                className="type"
                value={setEventtype}
                onChange={(e) => setEventtype(e.target.value)}
              >
                <option value="">All Types</option>
                <option value="Online">Online</option>
                <option value="Offline">Offline</option>
              </select>
            </div>
          </div>
        </div>
        <br />
        <div className="table-responsive">
          <table className="table table-bordered">
            <thead>
              <tr>
                <th>Event Name</th>
                <th>Description</th>
                <th>Location</th>
                <th>Start Date & Time</th>
                <th>End Date & Time</th>
                <th>Organizer</th>
                <th>Type</th>
                <th>Max Attendees</th>
                <th>Tags</th>
                <th>Actions</th>
              </tr>
            </thead>

            <tbody>
              {SearchEvents.length === 0 ? (
                <tr>
                  <td colSpan="10" className="text-center">
                    No events found.
                  </td>
                </tr>
              ) : (
                SearchEvents.map((e) => (
                  <tr key={e.id}>
                    <td>{e.name}</td>
                    <td>{e.description}</td>
                    <td>{e.location}</td>
                    <td>{new Date(e.start).toLocaleString()}</td>
                    <td>{new Date(e.end).toLocaleString()}</td>
                    <td>{e.organizer}</td>
                    <td>{e.type}</td>
                    <td>{e.maxAttendees}</td>
                    <td>
                      {Array.isArray(e.tags) ? e.tags.join(", ") : e.tags}
                    </td>
                    <td>
                      <Link
                        to={`/edit/${e.id}`}
                        className=" btn-warning me-2 mb-2 p-1 ps-4 pe-4"
                        style={{ textDecoration: "none" }}
                      >
                        Edit
                      </Link>
                      <button
                        onClick={() => deleteEvent(e.id)}
                        className=" btn-danger ps-3 pe-3"
                      >
                        Delete
                      </button>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
export default DashBoard;
