import React, { useState, useEffect } from "react";
import { Link, useNavigate, useParams } from "react-router-dom";
import { getEvents, saveEvents } from "../utils/storage";

function AddEditEvent() {
  const { id } = useParams();
  const navigate = useNavigate();

  const [event, setEvent] = useState({
    name: "",
    description: "",
    location: "",
    start: "",
    end: "",
    organizer: "",
    type: "Online",
    maxAttendees: "",
    tags: "",
  });

  const [errors, setErrors] = useState({});

  useEffect(() => {
    if (id) {
      const allEvents = getEvents();
      const found = allEvents.find((e) => e.id === id);
      if (found) {
        setEvent({
          ...found,
          tags: Array.isArray(found.tags) ? found.tags.join(", ") : found.tags,
        });
      }
    }
  }, [id]);

  const handleChange = (e) => {
    setEvent({ ...event, [e.target.name]: e.target.value });
  };

  const validate = () => {
    const newErrors = {};

    if (!event.name) newErrors.name = "Event name is required";
    if (!event.description) newErrors.description = "Description is required";
    if (!event.location) newErrors.location = "Location is required";
    if (!event.start) newErrors.start = "Start date & time is required";
    if (!event.end) newErrors.end = "End date & time is required";

    if (event.start && event.end) {
      const startTime = new Date(event.start);
      const endTime = new Date(event.end);
      if (startTime >= endTime) {
        newErrors.dateOrder = "Start must be before End";
      }
    }

    if (!event.organizer) newErrors.organizer = "Organizer is required";
    if (!event.type) newErrors.type = "Type is required";
    if (!event.maxAttendees || Number(event.maxAttendees) <= 0) {
      newErrors.maxAttendees = "Attendees must be > 0";
    }
    if (!event.tags) newErrors.tags = "Tags required";

    setErrors(newErrors);

    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = (e) => {
    e.preventDefault();

    if (!validate()) return;

    const allEvents = getEvents();
    const newEvent = {
      ...event,
      id: id || Date.now().toString(),
      tags: event.tags.split(","),
    };

    let updatedEvents;
    if (id) {
      updatedEvents = allEvents.map((e) => (e.id === id ? newEvent : e));
    } else {
      updatedEvents = [...allEvents, newEvent];
    }

    saveEvents(updatedEvents);
    navigate("/");
  };

  return (
    <div className="container mt-4">
      <h2>{id ? "Edit Event" : "Add Event"}</h2>
      <form onSubmit={handleSubmit} noValidate>
        <div className="mb-3">
          <div className="heading">
            <label>Event Name</label>
            <Link to="/">Back</Link>
          </div>
          <input
            type="text"
            name="name"
            value={event.name}
            onChange={handleChange}
            className={"form-control"}
          />
          {errors.name && <div style={{ color: "red" }}>{errors.name}</div>}
        </div>
        <div className="mb-3">
          <label>Description</label>
          <textarea
            name="description"
            value={event.description}
            onChange={handleChange}
            className={"form-control .descri"}
          ></textarea>
          {errors.description && (
            <div style={{ color: "red" }}>{errors.description}</div>
          )}
        </div>
        <div className="mb-3">
          <label>Location</label>
          <input
            type="text"
            name="location"
            value={event.location}
            onChange={handleChange}
            className={"form-control .loc"}
          />
          {errors.location && (
            <div style={{ color: "red" }}>{errors.location}</div>
          )}
        </div>
        <div className="mb-3">
          <label>Start Date & Time</label>
          <input
            type="datetime-local"
            name="start"
            value={event.start}
            onChange={handleChange}
            className={"form-control"}
          />
          {errors.start && <div style={{ color: "red" }}>{errors.start}</div>}
        </div>
        <div className="mb-3">
          <label>End Date & Time</label>
          <input
            type="datetime-local"
            name="end"
            value={event.end}
            onChange={handleChange}
            className={"form-control"}
          />
          {errors.end && <div style={{ color: "red" }}>{errors.end}</div>}
        </div>
        {errors.dateOrder && (
          <div className="text-danger mb-3">{errors.dateOrder}</div>
        )}
        <div className="mb-3">
          <label>Organizer</label>
          <input
            type="text"
            name="organizer"
            value={event.organizer}
            onChange={handleChange}
            className={"form-control"}
          />
          {errors.organizer && (
            <div style={{ color: "red" }}>{errors.organizer}</div>
          )}
        </div>
        <div className="mb-3">
          <label>Event Type</label>
          <select
            name="type"
            value={event.type}
            onChange={handleChange}
            className={"form-select"}
          >
            <option value="Online">Online</option>
            <option value="Offline">Offline</option>
          </select>
          {errors.type && <div style={{ color: "red" }}>{errors.type}</div>}
        </div>
        <div className="mb-3">
          <label>Max Attendees</label>
          <input
            type="number"
            name="maxAttendees"
            value={event.maxAttendees}
            onChange={handleChange}
            min="1"
            className={"form-control"}
          />
          {errors.maxAttendees && (
            <div style={{ color: "red" }}>{errors.maxAttendees}</div>
          )}
        </div>

        {/* Tags */}
        <div className="mb-3">
          <label>Tags (comma separated)</label>
          <input
            type="text"
            name="tags"
            value={event.tags}
            onChange={handleChange}
            className={"form-control"}
          />
          {errors.tags && <div style={{ color: "red" }}>{errors.tags}</div>}
        </div>

        <button type="submit" className="btn-success mb-5">
          {id ? "Update Event" : "Add Event"}
        </button>
      </form>
    </div>
  );
}

export default AddEditEvent;
