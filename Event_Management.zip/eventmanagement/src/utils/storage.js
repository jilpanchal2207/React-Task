export const getEvents = () => {
  const events = localStorage.getItem('events');
  return events ? JSON.parse(events) : [];
};

export const saveEvents = (events) => {
  localStorage.setItem('events', JSON.stringify(events));
};
