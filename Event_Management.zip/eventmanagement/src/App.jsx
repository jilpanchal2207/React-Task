import { useState } from "react";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import "./App.css";
import DashBoard from "./pages/DashBoard";
import AddEditEvent from "./pages/AddEditEvent";
import RecordForm from "./components/RecordForm";

function App() {
  return (
    <>
      <Router>
        <Routes>
          <Route path="/" element={<DashBoard />} />
          <Route path="/add" element={<AddEditEvent />} />
          <Route path="/edit/:id" element={<AddEditEvent />} />
        </Routes>
      </Router>
    </>
  );
}

export default App;
